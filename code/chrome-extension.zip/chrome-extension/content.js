console.log("YouTube content script loaded");
